# Freeze log (root-free experiment) — written before the main run

Regression gate: modified simulator reproduces data/main_{node,local,edge}.csv exactly (100 graphs each): PASS
Pilot (300 trials/graph, offset 10^6) -> levels (mechanical rule; pilot curve is monotone through m=34, so m_floor=34):
  P*=0.90->m=28 (12 survivors, pooled pilot P=0.903) | 0.75->m=30 (10, 0.777) | 0.50->m=33 (7, 0.449) | 0.25->m=34 (6, 0.345)
  NOTE: the 0.25 target is not actually reached (closest eligible m is 34, the edge of the pre-specified candidate range m<=34); kept as specified.
  Primary level: m=33.
Analysis script dry-run: only on previously seen protected-root data (main_node.csv); no root-free pilot/main data used for any analysis beyond pooled P(m).

sha256:
ddc2e8bd12ff4b8d63390ecf369379ceb1910098ad57bb09a5dbeec997c0fedb  PROTOCOL_rootfree.md
a954bc5e2869ce415cd76a651d9db63cf144875688d3357fe2bcc4aabb104b79  LEVELS_rootfree.json
e8dbd1fdd1aad01f9aa678344ba20f42f0dd15156ce91382446ea16f3b2538ed  rootfree_levels.py
25cb16e87f1c49a574043b9dc0e37d4c91ff677bfae31f474a6b3c37703e1edd  rootfree_analysis.py
f04214a676fce587280e0c63a68b8db2e6b9aa624d2877ca39b7952bbf342a7c  screen_sim.c
fe46f1b13ab79e0b20bd21c277515537b1688b2694b4e5889faf7c2a2feb516b  screen_run.py
72f90d9b8f5311c55b4ebe13a1014194e750b19382c93525aebfaa9e7a086e0a  regress_old_modes.py
c7e66b5ecd0eb5a542fac821e20e5729d29b5c477a06149a15715d1d2e461902  data/rf_pilot_nodefree.csv
